﻿namespace Assets.Scripts.V1
{
    [System.Serializable]
    public enum PlatformOrientation {
        North,
        South,
        East,
        West

    }
}
