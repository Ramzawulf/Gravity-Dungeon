﻿using UnityEngine;

namespace Assets.Scripts.V1
{
    public class PlatformManager : MonoBehaviour {

        // Use this for initialization
        void Start () {
            BuildEnvironment ();
        }
	
        // Update is called once per frame
        void Update () {
		
        }

        void BuildEnvironment ()
        {
            throw new System.NotImplementedException ();
        }
    }
}
