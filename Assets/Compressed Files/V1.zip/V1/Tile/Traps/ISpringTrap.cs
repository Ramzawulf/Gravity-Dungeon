﻿namespace Assets.Scripts.Tile.Traps
{
    public interface ISpringTrap {
        void Spring (float f);
    }
}
