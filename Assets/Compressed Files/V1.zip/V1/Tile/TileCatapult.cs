﻿using UnityEngine;

namespace Assets.Scripts.Tile
{
    public class TileCatapult : global::Assets.Scripts.Tile.Tile {

        public override void OnStepIn (GameObject go)
        {
            //ToDo
        }
    }
}
