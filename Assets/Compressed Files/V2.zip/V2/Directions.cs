﻿namespace Assets.Scripts.V2
{
    public enum Directions {
        Up,
        Down,
        Forward,
        Back,
        Right,
        Left,
        Undefined
    }
}
